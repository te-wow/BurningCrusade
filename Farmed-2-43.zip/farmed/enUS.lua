--- Default Language -----
---Application messages
farmed_lang_loaded="Farmed is loaded, type /farmed to access options";
farmed_lang_optmain="Farmed Commands:";
farmed_lang_optcom1="     show - show farmed window";
farmed_lang_optcom2="     hide - hide farmed window";
farmed_lang_optcom3="     options - configure farmed";
farmed_lang_optcom4="     refresh - update farmed display";
farmed_lang_optcom5="     status - list ststus of add-on";
farmed_lang_optcom6="     debug - switch debug mode on/off";
farmed_lang_optcom7="     reset - reset sesison tracking";

farmed_lang_opterr="Unrecognised command."; -- new -- message for incorrect command line option.

farmed_lang_optshow="show" -- new - command line option for show ... must be lower case
farmed_lang_opthide="hide" -- new - command line option for hide ... must be lower case
farmed_lang_optconfig="options" -- new - command line option to display options/config ... must be lower case
farmed_lang_cmdRefresh="refresh" -- new - command line option for refresh ... must be lower case
farmed_lang_cmdStatus="status" -- new - command line option for status ... must be lower case
farmed_lang_cmdDebug="debug" -- new - command line option for debug toggler ... must be lower case
farmed_lang_cmdReset="reset" -- new - command line option for resetting sesison ... must be lower case

farmed_lang_refresComplete="Farmed refreshed.";

--Dialog Titles
farmed_lang_bags="Bag slots free:";
farmed_lang_money="Money:";
farmed_lang_gathered="Gathered";
farmed_lang_ore="Metal & Stone";
farmed_lang_meat="Meat";
farmed_lang_gem="Gem";
farmed_lang_herb="Herb";
farmed_lang_cloth="Cloth";
farmed_lang_leather="Leather";
farmed_lang_element="Elemental";
farmed_lang_enchanting="Enchanting";
farmed_lang_other="Other Items";
farmed_lang_othercat="Trade Goods";
farmed_lang_othercat1="Materials";
farmed_lang_othercat2="Parts";
farmed_lang_othercatIDs="#88165;"; --- added 5.4 to support custom other items
farmed_lang_items="Items";
farmed_lang_quest="Quest";
farmed_lang_cooking="Cooking"; --- added for padaria
farmed_lang_consumable="Consumable";
farmed_lang_garrison="Garrison Mat's";
farmed_lang_gresource="Resources";
farmed_lang_week="this week";


farmed_lang_ic_uncommon="Uncommon" -- new -- uncommon summary text
farmed_lang_ic_rare="Rare" -- new -- uncommon summary text
farmed_lang_ic_epic="Epic" -- new -- uncommon summary text

farmed_lang_none="None" -- new -- not items found

--Broker Menu Text
farmed_lang_bkr_open="Open" -- new -- not items found
farmed_lang_bkr_config="Configure" -- new -- not items found
farmed_lang_bkr_config="Configure" -- new -- not items found
farmed_lang_bkr_refresh="Refresh" -- new -- not items found
farmed_lang_bkr_resetsession="Reset Session" -- new -- not items found


--Inventory Item Filter
farmed_lang_ItemFilter="Armor,Container,Miscellaneous,Recipe,Weapon";

----Option Window Text

farmed_opt_general="General Option";
farmed_opt_show="Show Farmed";
farmed_opt_money="Show Money";
farmed_opt_bags="Show Bag Summary";

farmed_opt_items="Item Options";
farmed_opt_uncommon="Show Uncommon";
farmed_opt_rare="Show Rare/Epic";
farmed_opt_itemcount="Show count only."; -- New 

farmed_opt_materials="Material Options";
farmed_opt_ore="Show Metal/Stone";
farmed_opt_meat="Show Meat";
farmed_opt_herbs="Show Herbs";
farmed_opt_elements="Show Elementals";
farmed_opt_gems="Show Gems";
farmed_opt_enchanting="Show Enchanting";
farmed_opt_cloth="Show Cloth";
farmed_opt_leather="Show Leather";
farmed_opt_other="Show Other Items";
farmed_opt_consumable="Show Consumables";
farmed_opt_cooking="Show Cooking Ingr."; -- new for pandaria
farmed_opt_garrison="Show Garrison Mat's";
farmed_opt_announce_header="Annouce" -- New 
farmed_opt_announce="Loot On Screen";
farmed_opt_announcechat="Loot In Chat";
farmed_opt_trap="When I can drop trap";


farmed_opt_quest="Show Quest Items";

-- Farmed Option Descriptions
farmed_opt_show_desc="Show/hide the farmed floating window."; -- New 
farmed_opt_money_desc="Show/hide money summary."; -- New 
farmed_opt_bags_desc="Show/hide the bag space summary."; -- New 

farmed_opt_uncommon_desc="Include uncommon items in farmed."; -- New 
farmed_opt_rare_desc="Include rare/epic in farmed."; -- New 
farmed_opt_itemcount_desc="Show a summary of items by rarity." -- New 

farmed_opt_ore_desc="Include Metal/Stone in farmed."; -- New 
farmed_opt_meat_desc="Include Meat in farmed."; -- New 
farmed_opt_herbs_desc="Include Herbs in farmed."; -- New 
farmed_opt_elements_desc="Include elemental materisals in farmed."; -- New 
farmed_opt_gems_desc="Include Gems  in farmed."; -- New 
farmed_opt_enchanting_desc="Include Enchanting materials in farmed."; -- New 
farmed_opt_cloth_desc="Include Cloth  in farmed."; -- New 
farmed_opt_leather_desc="Include Leather in farmed."; -- New 
farmed_opt_cooking_desc="Include cooking ingredients in farmed."; -- New 
farmed_opt_other_desc="Include Other Items in farmed."; -- New 
farmed_opt_consumable_desc=" in farmed. Consumables in farmed."; -- New 
farmed_opt_garrison_desc=" Includes garrison Materials (Timber and Resources)."; -- New 

farmed_opt_announce_desc="Annouce looted matrials in the default alert frame.";
farmed_opt_announcechat_desc="Annouce looted matrials in the default chat window.";
farmed_opt_quest_desc="Include Quest Items in farmed.";

farmed_opt_trap_desc="Announce when traps should be dropped.";


farmed_opt_config_autorefresh="Auto Refresh List" -- New 
farmed_opt_config_autorefresh_desc="Auto refresh the farmed list every 30 seconds. (out of combat)" ;-- New 

farmed_opt_display={a="Actual and Session",b="Actual Only", c="Session Only"};
farmed_opt_display_title="Display Mode:";
farmed_opt_display_desc="Sisplay whcih values in databroker and window? Actual = In bag total; Session = farmed in current sesison.";

----Farmed Specific Types

farmed_def_types_garrisonmats={114781, 115508,116053,119813,119810,119814,119819,119817,119815,113681,116394,116395}
farmed_garrison_counts={0,0,0,0,0,0,0,0,0,0,0,0}
farmed_lang_garrisonmats={"Timber", "Rock","Seed","Caged Beast (fur)","Caged Beast (Meat)","Caged Beast (Leather)","Caged Might Clefthoof (Leather+Blood)", "Caged Mighty Riverbeast (Meat+Blood)", "Caged Mighty Wolf (Fur+Blood)", "Iron Scraps","Outpost Assembly Note","Outpost Construction Guide"};
farmed_lang_trappable="86932,86731,87021," -- trappable elite npc
farmed_lang_trappable=farmed_lang_trappable.."78574,76711,73234,76710,82119,86732,72881,76326,77513,83483,75680,86000,77519,85537,76576,78920,78918,84798,80420,78919,78364,86731,86730,81898,78576,78575,85031,80136,50990,86520,79034,76389,75771,78528,78572,78570,78571,72162,86847," -- trappable clefthoof npcs
farmed_lang_trappable=farmed_lang_trappable.."84045,,80261,,86932,86931,,77886,,73619,,76150,,76337,,84793,,76593,,10981,,74748,,76597,,76707,,76705,,81000,,74712,,74169,,82912,,81774,,74206,,74208,,82209,,82205,,87107,,81902,,86414,,81001,,72991,,76181,,80160,,79755,,84044,,82307,,82308,,80263,,58456,,82535,,81718,,86851," -- trappable wolf npcs

farmed_lang_trappable=farmed_lang_trappable.."78603,82174,83664,80175,73960,80997,81084,81745,81085,81083,81828,86741,77186,77168,78443,84867,77747,82452,79148,78371,78385,78387,82258,74630,79149,82257,73686,77212,75456,76497,75457,84917," -- trappable elekk npcs

farmed_lang_trappable=farmed_lang_trappable.."77187,78278,83470,81214,82049,77689,81489,82219,85832,81940,83469,86727," -- trappable talbuk npcs

farmed_lang_trapinstr="Drop trap for"

----Key Binding

BINDING_HEADER_FARMED_TITLE = "Farmed Bindings";
BINDING_NAME_FARMED_TOGGLE = "Toggle Farmed";




