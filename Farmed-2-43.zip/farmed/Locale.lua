﻿--Author      : LintyDruid
--Localisation Control


function farmed_lang_Set(language)
	 farmed_lang_Init(language);
end

function farmed_lang_Init(language)
	if (language== nil) then
		language = GetLocale();
	end
	
	--Apply local overlay
	if (language=="deDE") then
		farmed_Locale_German();
		farmed_Message("Language set to German ("..language..")");
	elseif (language=="esES") then
		farmed_Locale_Spanish();
		farmed_Message("Language set to Spanish ("..language..")");
	elseif (language=="frFR") then
		farmed_Locale_French();
		farmed_Message("Language set to French ("..language..")");
	elseif (language=="koKR") then
		farmed_Locale_Korea();
		farmed_Message("Language set to Korean ("..language..")");
	elseif (language=="zhCN") then
		farmed_Locale_China();
		farmed_Message("Language set to Chinese ("..language..")");
	elseif (language=="zhTW") then
		farmed_Locale_Taiwan();
		farmed_Message("Language set to Taiwanese("..language..")");
	else
		farmed_Message("Language set to English ("..language..")");
	end
	
	--Refresh screens, etc
	farmed_lang_Refresh();
	
	
end

function farmed_lang_Refresh()

	
	


	
end
