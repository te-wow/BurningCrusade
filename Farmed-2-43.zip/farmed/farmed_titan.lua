-- Author      : Linty
------------------------Titan Pannel Mngr---------------------
farmed_titan_loaded=false

if not IsAddOnLoaded("Titan") then
	-- Do not load if Titanbar is not loaded
	return
end

--- Init 


function farmedTitanButton_load()

	--- !! Important ID must match Bottopn Name in XML (format : TitanPanel<ID>Button)

	this.registry = {
    id = "Farmed",
    menuText = "Farmed",
    tooltipTitle = "Farmed",
    tooltipTextFunction = "farmedTitanButton_getTooltipText",
    category = "Information",
    builtin = 1,
    icon = 'Interface\\Icons\\INV_Misc_Gem_Diamond_06.blp',
    iconWidth = 16,
	iconButtonWidth = 16,    
    buttonTextFunction = "farmedTitanButton_getButtonText",
	savedVariables = {
			ShowIcon = 1,    
	},
  }

  farmed_titan_loaded=true
end


function farmedTitanButton_getButtonText()

	return farmed_titan_data.title;
end

function farmedTitanButton_getTooltipText()
		ttText = farmed_titan_data.tooltip;

		ttText=ttText.."\n|cff30C0FFHint: Left Click to show &|r"
		ttText=ttText.."\n|cff30C0FFRight Click for Options.|r"

	return ttText
end


function farmedTitanButton_menu_open()
	farmed_show(); 

end

function farmedTitanButton_menu_refresh()
	 farmed_buildlist();
	 farmed_gen();
	 farmed_Message(farmed_lang_refresComplete);
end

function farmedTitanButton_menu_cfg()
	ShowUIPanel(InterfaceOptionsFrame);
end

function farmedTitanButton_menu_reset()

		farmed_resetTracking(); 
		farmed_gen();
end

function TitanPanelRightClickMenu_PrepareFarmedMenu()

  TitanPanelRightClickMenu_AddTitle("Farmed");

  TitanPanelRightClickMenu_AddCommand("Show", nil, "farmedTitanButton_menu_open");
  TitanPanelRightClickMenu_AddCommand("Referesh", nil, "farmedTitanButton_menu_refresh");
  TitanPanelRightClickMenu_AddCommand("Reset", nil, "farmedTitanButton_menu_reset");
  TitanPanelRightClickMenu_AddSpacer();  
  TitanPanelRightClickMenu_AddCommand("Configure..", nil, "farmedTitanButton_menu_cfg");
  TitanPanelRightClickMenu_AddSpacer();
  TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, "Farmed", TITAN_PANEL_MENU_FUNC_HIDE);
end

function farmedTitanButton_OnClick(button)
	if (button == "LeftButton") then
         farmedTitanButton_menu_open()
     end
end
