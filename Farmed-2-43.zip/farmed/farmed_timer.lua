
farmed_timer = LibStub("AceAddon-3.0"):NewAddon("farmed_ace_timer","AceTimer-3.0")

function farmed_timer:init()
  farmed_init_addon();
end

function farmed_timer:execute()
  farmed_executeTimer();
end