﻿-- Author      : LintyDruid

-- Localisation

function farmed_Locale_Korean()

end
