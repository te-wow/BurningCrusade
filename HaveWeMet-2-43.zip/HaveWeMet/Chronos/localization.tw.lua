﻿--------------------------------------------------
-- localization.tw.lua (Chinese Traditional)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation:

if ( GetLocale() == "zhTW" ) then

	-- Please submit your translation to everyone@cosmosui.org

end
