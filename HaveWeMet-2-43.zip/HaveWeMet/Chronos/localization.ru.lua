﻿--------------------------------------------------
-- localization.ru.lua (Russian)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 22:41:28Z $
-- Translation:

if ( GetLocale() == "ruRU" ) then

	-- Please submit your translation to everyone@cosmosui.org

end
