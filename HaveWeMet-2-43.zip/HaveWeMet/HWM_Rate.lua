﻿-- Author      : Linty
-- Create Date : 1/10/2010 2:25:47 PM
HWM_Rate_Active={Server="", Name=""};

function HWM_Rate_Set()
	local prating, pdata=hwm:PlayerInfo(HWM_Rate_Active.Server, HWM_Rate_Active.Name);
	
	if (pdata==nil) then
		return;
	end
	
	pdata.Rating = math.floor(HWM_Rate_rate:GetValue());
	pdata.Note = HWM_Rate_note:GetText();
	
	if (HWM_Browse_Frame:IsVisible()) then
		hwm.browser:Update();
	end
	
	HWM_Rate:Hide();
end


function HWM_Rate_ValueChanged()
	if (HWM_Rate:IsShown()) then
		local nrate= math.floor(HWM_Rate_rate:GetValue());
		
		HWM_Rate_label:SetText(hwm.lang.RateWinLabel:format(HWM_Rate_Active.Name.."-"..
					HWM_Rate_Active.Server,"|cff"..hwm.lang.RateColors[nrate]..
					hwm.lang.RateLabels[nrate]));
	end
end

function HWM_Rate_Show(prealm, pname)
	HWM_Rate_Active.Server=prealm;
	HWM_Rate_Active.Name=pname;
	
	local prating, pdata=hwm:PlayerInfo(prealm, pname);
	
	if (pdata==nil) then
		return;
	end
	
	
	HWM_Rate_label:SetText(hwm.lang.RateWinLabel:format(pname.."-"..
				prealm,"|cff"..hwm.lang.RateColors[pdata.Rating]..
				hwm.lang.RateLabels[pdata.Rating]));
				
	HWM_Rate_low:SetText("|cff"..hwm.lang.RateColors[1]..
				hwm.lang.RateLabels[1]);
				
	HWM_Rate_high:SetText("|cff"..hwm.lang.RateColors[5]..
				hwm.lang.RateLabels[5]);
	
	HWM_Rate_notelabel:SetText(hwm.lang.RateNoteLabel);
	
	HWM_Rate_note:SetText(pdata.Note);
	
	HWM_Rate_rate:SetValue(pdata.Rating);
	
	HWM_Rate:Show();
end
