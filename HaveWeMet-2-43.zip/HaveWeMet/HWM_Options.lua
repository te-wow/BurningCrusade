﻿
hwm_config={}
hwm_config.config={}

hwm_config.config.AceConfig = {
    name = "Have We Met",
    handler = nil,
    type = 'group',
    args = {

        b = {
            type = 'header',
            name = 'View Windows',
            order=100,
            
        },
        
        ba = {
            type = 'toggle',
            name = 'Show Browser',
            desc = 'Hide/Show Browser Window',
            set = function(info,val) hwm.utils:BrowseShow(val) end,
            get = function(info) return HWM_Browse_Frame:IsVisible() end,
            order=101,
        },
        
         bb = {
            type = 'toggle',
            name = 'Show Session Window',
            desc = 'Hide/Show Session Window',
            set = function(info,val) hwm.utils:SessionShow(val) end,
            get = function(info) return hwm.vars.showsession end,
            order=102,
        },

		a = {
            type = 'header',
            name = 'General Options',
			order=200,
            
        },
		
        aa = {
            type = 'toggle',
            name = 'Hide tooltip detail',
            desc = 'Hide detail in tooltip (Shift will show).?',
            set = function(info,val) HWM_Global.HideDetail=val end,
            get = function(info) return HWM_Global.HideDetail end,
			order=201,
        },
		
		 aa1 = {
            type = 'toggle',
            name = 'Disable sound',
            desc = '',
            set = function(info,val) HWM_Global.noSound=val end,
            get = function(info) return HWM_Global.noSound end,
			order=202,
        },
		
		-- ab = {
            -- type = 'toggle',
            -- name = 'Hide Mini Map Button',
            -- desc = '',
            -- set = function(info,val) hwm_config.config:SetMiniMap(info, val) end,
            -- get = function(info) return HWM_Global.noMinimapButton end,
			-- order=103,
        --},
		
		
		
	},
}

 hwm_config.config.AceOptionsTable= LibStub("AceConfig-3.0")

 hwm_config.config.AceOptionsTable:RegisterOptionsTable("hwm", hwm_config.config.AceConfig)
 hwm_config.config.AceDialog= LibStub("AceConfigDialog-3.0")
 hwm_config.config.AceDialog:AddToBlizOptions("hwm","Have We Met")



function hwm_config.config:SetMiniMap(info, val)
		HWM_Global.noMinimapButton=val

	
end
