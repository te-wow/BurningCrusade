﻿-- Author      : LintyDruid

-- English Localisation

function HWM_Locale_English()
	
	----- Genral
	
	hwm.lang.welcome="Have We Met has loaded (/HWM for commands)"; -- Addon Welcome Message
	hwm.lang.title="Have We Met?";
	
	hwm.lang.command1="Have We Met command:"; -- Cammand Line
	hwm.lang.command2="/HWM SESSION - Show session window."; -- Cammand Line
	hwm.lang.command3="/HWM BROWSE - Shows the data browser windows."; -- Cammand Line
	hwm.lang.command4="/HWM ADD <playername> - Manually adds a player from you realm to the list."; -- Cammand Line
	
	
	-- Command
	hwm.lang.cmd1="/hwm";
	hwm.lang.cmd2="/havewemet";
	hwm.lang.cmdShowSession="SESSION";
	hwm.lang.cmdShowBrowse="BROWSE";
	hwm.lang.cmdShowAdd="ADD";

	----Unit Tool Tip
	
	hwm.lang.tt_lastgrouped="Last Grouped/Raided"; -- Last Grouped: Label
	hwm.lang.tt_grouped="In parties for ";
	hwm.lang.tt_raided="In raid groups for ";
	hwm.lang.tt_raidact="Raid Instance Activity: ";
	hwm.lang.tt_dunact="Dungeon Activity: ";
	hwm.lang.tt_pvpact="PVP Activity: ";
	hwm.lang.tt_recentinst="Recent Instances: ";
	
	hwm.lang.tt_sessioninstr="Click name to change note and rating.";

	
	---regualrity Labeles
	hwm.lang.tt_rating ={"No, who are you?",
						"Once or Twice",
						"Yes, a few times",
						"Yes, we've grouped a lot",
						"Yes, I got your back",
						"lol, we're inseprable"};
	---Colors for labels
	hwm.lang.tt_ratingcol ={"808080",
						"808080",
						"80FFC0",
						"FF8080",
						"FFC000",
						"78BF78"};
	
	--INstance type labels
	 hwm.lang.DunDif ={"Normal", -- 1
							"Heroic",-- 2
							"Epic",-- 3
							"Unknown" -- 4
							}; 

	--INstance type labels
	 hwm.lang.DunTypes ={"Normal(5)", -- 1
							"Heroic(5)",-- 2
							"Heroic(10)",-- 3
							"Heroic(25)",-- 4
							"Normal(25)",-- 5
							"Unknown" -- 6
							}; 
	--- diabled 5.04 -> hwm.lang.RaidTypes ={"Normal(10)","Normal(25)","Heroic(10)","Heroic(25)"};
	
	-----Time Strings
	hwm.lang.Seconds="s";
	hwm.lang.Minutes="m";
	hwm.lang.Hours ="h";
	hwm.lang.Days ="d";
	
	-----Options Screen
	
	hwm.lang.OptHideDetails="Hide detail in tooltip (Shift Key will show).";
	
	-----Ratings Screen
	
	hwm.lang.RateWinLabel="Rating for %s : %s";
	hwm.lang.RateNoteLabel="Enter Note:";
	
	hwm.lang.RateTTLabel="Rating:";
	hwm.lang.RateTTNote="Note:";
	
	hwm.lang.RateLabels={"Poor","Needs Practice","OK","Reliable","Awesome"};
	hwm.lang.RateColors={"FF4040","FF8000","18609C","30C0FF","40CF40"};
	hwm.lang.RateHighlight={{1,0.25,0.25,0.1},{1,0.5,0,0.1},{0,0,0,0},{0.18,0.75,1,0.1},{0.25,0.81,0.25,0.1}};
	
	
	
	-----Session Display
	
	hwm.lang.NoSession="You have not joined any groups or raids during this session.";
	
	-----Browser Display
	hwm.lang.BrowNameSearch="Find Name";
	hwm.lang.BrowCol1="Name";
	hwm.lang.BrowCol2="Rating";
	hwm.lang.BrowCol3="Serv";
	hwm.lang.BrowCol4="Last Seen";
	hwm.lang.BrowFilter="More filter options:";
	hwm.lang.BrowFiltSess="This session";
	hwm.lang.BrowFiltServ="This server";
	hwm.lang.BrowFiltPop="Popular /\nRecent";
	hwm.lang.BrowStatus="Showing %s of %s records";
	hwm.lang.BrowCmdFind="Find";
	hwm.lang.BrowCmdEdit="Edit";
	hwm.lang.BrowCmdPst="Whisper";
	hwm.lang.BrowCmdWho="Who";

	----Key Binding

	BINDING_HEADER_HWM_TITLE = "Have We Met?";
	BINDING_NAME_HWM_BROW_TOGGLE = "Toggle Browser Window";
	BINDING_NAME_HWM_SESS_TOGGLE = "Toggle Session Window";

	
end