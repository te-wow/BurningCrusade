-- Author      : Linty
------------------------Titan Pannel Mngr---------------------
farmed_hwm_loaded=false

if not IsAddOnLoaded("Titan") then
	-- Do not load if Titanbar is not loaded
	return
end

--- Init 


function hwmTitanButton_load()

	--- !! Important ID must match Bottopn Name in XML (format : TitanPanel<ID>Button)

	this.registry = {
    id = "HWM",
    menuText = "Have We Met?",
    tooltipTitle = "Have We Met?",
    tooltipTextFunction = "hwmTitanButton_getTooltipText",
    category = "Information",
    builtin = 1,
    icon = 'Interface\\Icons\\INV_Misc_Gem_Diamond_06.blp',
    iconWidth = 16,
	iconButtonWidth = 16,    
    buttonTextFunction = "hwmTitanButton_getButtonText",
	savedVariables = {
			ShowIcon = 1,    
	},
  }

  farmed_hwm_loaded=true
end


function hwmTitanButton_getButtonText()

	return "Have We Met?";
end

function hwmTitanButton_getTooltipText()
		ttText = ""

		-- Write recent History
		ttText=ttText.."|cff00ff00Recent Players|r|cffffffff (this sesison)|r\n"
		if hwm.vars.sessionddata~=nil then
			
			
			table.sort(hwm.vars.sessionddata, function(ta, tb) return time()-ta.LastSeen>time()-tb.LastSeen end); -- Sort descending;
			
			local tmpcnt=0
			for key,data in pairs(hwm.vars.sessionddata) do
				if (tmpcnt<20) then
					ttText=ttText.."|cff"..data.Color.code..key.." - " .. data.Race.." "..data.Class..
											"|r\t"..hwm.utils:TimeString(time()-data.LastSeen).."\n"
				end
				tmpcnt=tmpcnt+1
			end
		else
			ttText=ttText.."None.\n"
		end

		--Tip
		ttText=ttText.."\n|cff30C0FFHint: Left Click to show players &|r"
		ttText=ttText.."\n|cff30C0FFRight Click for Options.|r"

	return ttText
end


function hwmTitanButton_menu_open()
	HWM_Browse_Frame:Show(); 

end

function hwmTitanButton_menu_sesssion()
	 hwm.utils:SessionToggle()
end

function hwmTitanButton_menu_cfg()
	ShowUIPanel(InterfaceOptionsFrame);
end



function TitanPanelRightClickMenu_PrepareHWMMenu()

  TitanPanelRightClickMenu_AddTitle("Farmed");

  TitanPanelRightClickMenu_AddCommand("Browse PLayers", nil, "hwmTitanButton_menu_open");
  TitanPanelRightClickMenu_AddCommand("Session", nil, "hwmTitanButton_menu_sesssion");
  TitanPanelRightClickMenu_AddSpacer();  
  TitanPanelRightClickMenu_AddCommand("Configure..", nil, "hwmTitanButton_menu_cfg");
  TitanPanelRightClickMenu_AddSpacer();
  TitanPanelRightClickMenu_AddCommand(TITAN_PANEL_MENU_HIDE, "HWM", TITAN_PANEL_MENU_FUNC_HIDE);
end

function hwmTitanButton_OnClick(button)
	if (button == "LeftButton") then
         hwmTitanButton_menu_open()
     end
end
